﻿using _2910_CadenGay_Lab6;
using _2910_CadenGay_Lab6.Components;
using _2910_CadenGay_Lab6.Data;
using System;
using System.Linq;

namespace _2910_CadenGay_Lab6.Data
{
    public class Library
    {
        private List<Book> books = new List<Book>();
        private List<User> users = new List<User>();
        private Dictionary<int, List<Book>> borrowedBooks = new Dictionary<int, List<Book>>();

        public Library()
        {

        }

        //Book Handling
        public void AddBook(Book newBook)
        {
            var existingBook = books.FirstOrDefault(b => b.Title == newBook.Title && b.Author == newBook.Author && b.ISBN == newBook.ISBN);
            if (existingBook != null)
            {
                //Book exists, increment quantity
                existingBook.Quantity++;
            }
            else
            {
                //New book, add to list
                newBook.Id = books.Any() ? books.Max(b => b.Id) + 1 : 1;
                books.Add(newBook);
            }
        }

        public void EditBook(Book updatedBook)
        {
            var book = books.FirstOrDefault(b => b.Id == updatedBook.Id);
            if (book != null)
            {
                book.Title = updatedBook.Title;
                book.Author = updatedBook.Author;
                book.ISBN = updatedBook.ISBN;
            }
        }

        public void DeleteBook(int bookId)
        {
            var book = books.FirstOrDefault(b => b.Id == bookId);
            if (book != null)
            {
                if (book.Quantity > 1)
                {
                    // If more than one copy exists, decrement the quantity
                    book.Quantity--;
                }
                else
                {
                    // Only one copy, remove it
                    books.Remove(book);
                }
            }
        }

        public IEnumerable<Book> GetBooks()
        {
            return books;
        }

        public IEnumerable<Book> GetBorrowedBooksByUser(int userId)
        {
            //Check if the user has borrowed any books
            if (borrowedBooks.ContainsKey(userId))
            {
                //Return a list of books borrowed by the user
                return borrowedBooks[userId];
            }
            else
            {
                //If the user hasn't borrowed any books, return an empty list
                return Enumerable.Empty<Book>();
            }
        }

        //User stuff
        public void AddUser(User user)
        {
            user.Id = users.Any() ? users.Max(u => u.Id) + 1 : 1;
            users.Add(user);
        }

        public void EditUser(User updatedUser)
        {
            var user = users.FirstOrDefault(u => u.Id == updatedUser.Id);
            if (user != null)
            {
                user.Name = updatedUser.Name;
                user.Email = updatedUser.Email;
            }
        }

        public void DeleteUser(int userId)
        {
            var user = users.FirstOrDefault(u => u.Id == userId);
            if (user != null)
            {
                users.Remove(user);
            }
        }

        public IEnumerable<User> GetUsers()
        {
            return users;
        }

        //Borrows and returnss
        public void BorrowBook(int bookId, int userId)
        {
            var book = books.FirstOrDefault(b => b.Id == bookId);
            var user = users.FirstOrDefault(u => u.Id == userId);
            if (book != null && user != null)
            {
                if (!borrowedBooks.ContainsKey(userId))
                {
                    borrowedBooks[userId] = new List<Book>();
                }
                borrowedBooks[userId].Add(book);
                books.Remove(book);
            }
        }

        public void ReturnBook(int bookId, int userId)
        {
            if (borrowedBooks.ContainsKey(userId))
            {
                var book = borrowedBooks[userId].FirstOrDefault(b => b.Id == bookId);
                if (book != null)
                {
                    borrowedBooks[userId].Remove(book);
                    books.Add(book);
                }
            }
        }

        public Dictionary<User, List<Book>> GetBorrowedBooks()
        {
            return borrowedBooks.ToDictionary(kvp => users.FirstOrDefault(u => u.Id == kvp.Key), kvp => kvp.Value);
        }
    }
}
