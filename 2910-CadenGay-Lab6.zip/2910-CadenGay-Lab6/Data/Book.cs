﻿using _2910_CadenGay_Lab6;
using _2910_CadenGay_Lab6.Components;
using _2910_CadenGay_Lab6.Data;
namespace _2910_CadenGay_Lab6.Data
{
    public class Book()
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Author { get; set; }
        public string ISBN { get; set; }
        public int Quantity { get; set; } = 1;
    }
}


