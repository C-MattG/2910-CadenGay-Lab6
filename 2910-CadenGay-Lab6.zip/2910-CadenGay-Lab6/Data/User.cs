﻿using _2910_CadenGay_Lab6;
using _2910_CadenGay_Lab6.Components;
using _2910_CadenGay_Lab6.Data;

namespace _2910_CadenGay_Lab6.Data
{
    public class User
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
    }
}
